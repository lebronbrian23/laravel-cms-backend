<?php $__env->startSection('content'); ?>

<section class="w3-padding">

    <h2>Add Social Media.</h2>

    <form method="post" action="/console/social-media/add" novalidate class="w3-margin-bottom">

        <?php echo csrf_field(); ?>

        <div class="w3-margin-bottom">
            <label for="name">Name:</label>
            <input type="name" name="name" id="title" value="<?php echo e(old('name')); ?>" required>

            <?php if($errors->first('name')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('name')); ?></span>
            <?php endif; ?>
        </div>

        <div class="w3-margin-bottom">
            <label for="url">url:</label>
            <input type="text" name="url" id="title" value="<?php echo e(old('url')); ?>" required>

            <?php if($errors->first('url')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('url')); ?></span>
            <?php endif; ?>
        </div>


        <div class="w3-margin-bottom">
            <label for="type">Type:</label>
            <input type="text" name="type" id="type" value="<?php echo e(old('type')); ?>" required>

            <?php if($errors->first('type')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('type')); ?></span>
            <?php endif; ?>
        </div>
        <button type="submit" class="w3-button w3-green">Add Social Media.</button>

    </form>

    <a href="/console/social-media/list">Back to Social Media. List</a>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/LebronBrianSinza1/Desktop/Humber College/sem 2/HTTP-5212-RNA/PHP/assignments/Assignment 3/laravel-blade-cms/resources/views/social-media/add.blade.php ENDPATH**/ ?>