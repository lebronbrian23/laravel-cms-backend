<?php $__env->startSection('content'); ?>

<section>
    <!--Banner-->
    <div class="w3-center w3-padding-24 page-banner">
        <h3>Add Content Block</h3>
    </div>
    <!--Content-->
    <div class="w3-container w3-padding-32">
    <form method="post" action="/console/skill/add" novalidate class="w3-margin-bottom">

        <?php echo csrf_field(); ?>

        <div class="w3-row-padding w3-margin-bottom">
            <div class="w3-col m4 w3-right-align">
            <label for="name">Name:</label>
            </div><div class="w3-col m4">
            <input type="name" name="name" id="title" value="<?php echo e(old('name')); ?>" required>

            <?php if($errors->first('name')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('name')); ?></span>
            <?php endif; ?>
        </div></div>

        <button type="submit" class="w3-button button">Add Skill</button>

    </form>

    <a href="/console/skill/list">Back to List</a>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/LebronBrianSinza1/Desktop/Humber College/sem 2/HTTP-5212-RNA/PHP/assignments/Assignment 3/laravel-blade-cms/resources/views/skill/add.blade.php ENDPATH**/ ?>