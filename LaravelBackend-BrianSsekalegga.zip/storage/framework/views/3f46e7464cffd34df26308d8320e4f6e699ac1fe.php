<?php $__env->startSection('content'); ?>

<section>
    <!--Banner-->
    <div class="w3-center w3-padding-24 page-banner">
        <h3>Manage Projects</h3>
    </div>
    <!--Content-->
    <div class="w3-container w3-center w3-padding-32">
    <div class="w3-content w3-justify">
      <table class="w3-table w3-bordered w3-white">
        <tr>
            <th></th>
            <th>Title</th>
            <th>Slug</th>
            <th>Type</th>
            <th>Created</th>
            <th></th>
            <th></th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if($project->image): ?>
                        <img src="<?php echo e(asset('/storage/'.$project->image)); ?>" width="50">
                    <?php endif; ?>
                </td>
                <td><?php echo e($project->title); ?></td>
                <td>
                    <a href="/project/<?php echo e($project->slug); ?>">
                        <?php echo e($project->slug); ?>

                    </a>
                </td>
                <td><?php echo e($project->type->title); ?></td>
                <td><?php echo e($project->created_at->format('M j, Y')); ?></td>
                <td><a href="/console/projects/image/<?php echo e($project->id); ?>" class="fake-button">Image</a></td>
                <td><a href="/console/projects/edit/<?php echo e($project->id); ?>" class="fake-button">Edit</a></td>
                <td><a href="/console/projects/delete/<?php echo e($project->id); ?>" class="fake-button">Delete</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div class="w3-center w3-padding-16">
            <a href="/console/projects/add" class="w3-button button">New Project</a>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/LebronBrianSinza1/Desktop/Humber College/sem 2/HTTP-5212-RNA/PHP/assignments/Assignment 3/laravel-blade-cms/resources/views/projects/list.blade.php ENDPATH**/ ?>