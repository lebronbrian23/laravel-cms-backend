<?php $__env->startSection('content'); ?>

<section class="w3-padding">

    <h2>Edit Content Block</h2>

    <form method="post" action="/console/content-blocks/edit/<?php echo e($content_block->id); ?>" novalidate class="w3-margin-bottom">

        <?php echo csrf_field(); ?>

        <div class="w3-margin-bottom">
            <label for="name">Name:</label>
            <input type="text" name="name" id="name" value="<?php echo e(old('name', $content_block->name)); ?>" required>

            <?php if($errors->first('name')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('name')); ?></span>
            <?php endif; ?>
        </div>

        <div class="w3-margin-bottom">
            <label for="description">Description:</label>
            <textarea name="description" id="description" required><?php echo e(old('description', $content_block->description)); ?></textarea>

            <?php if($errors->first('description')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('description')); ?></span>
            <?php endif; ?>
        </div>

        <div class="w3-margin-bottom">
            <label for="type">Type:</label>
            <input type="text" name="type" id="type" value="<?php echo e(old('type', $content_block->type)); ?>" required>

            <?php if($errors->first('type')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('type')); ?></span>
            <?php endif; ?>
        </div>
        <button type="submit" class="w3-button w3-green">Edit Content Block</button>

    </form>

    <a href="/console/content-blocks/list">Back to Content Block List</a>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/LebronBrianSinza1/Desktop/Humber College/sem 2/HTTP-5212-RNA/PHP/assignments/Assignment 3/laravel-blade-cms/resources/views/content_blocks/edit.blade.php ENDPATH**/ ?>