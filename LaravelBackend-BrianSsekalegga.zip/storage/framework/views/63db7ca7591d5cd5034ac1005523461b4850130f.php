<?php $__env->startSection('content'); ?>

<section class="w3-padding">
    <div class="w3-center w3-padding-24 page-banner">
        <h3>Login</h3>
    </div>
    <!--Content-->
    <div class="w3-container w3-padding-32">
    <form method="post" action="/console/login" novalidate>

        <?php echo csrf_field(); ?>

        <div class="w3-row-padding w3-margin-bottom">
            <div class="w3-col m4 w3-right-align">
                <label for="email">Email Address:</label>
            </div><div class="w3-col m4">
                <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required>
            
            <?php if($errors->first('email')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
            </div>
        </div>

        <div class="w3-row-padding w3-margin-bottom">
            <div class="w3-col m4 w3-right-align">
                <label for="password">Password:</label>
            </div><div class="w3-col m4">
                <input type="password" name="password" id="password" required>

            <?php if($errors->first('password')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
            </div>  
        </div>

        <button type="submit" class="w3-button button">Log In</button>

    </form>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/LebronBrianSinza1/Desktop/Humber College/sem 2/HTTP-5212-RNA/PHP/assignments/Assignment 3/laravel-blade-cms/resources/views/console/login.blade.php ENDPATH**/ ?>