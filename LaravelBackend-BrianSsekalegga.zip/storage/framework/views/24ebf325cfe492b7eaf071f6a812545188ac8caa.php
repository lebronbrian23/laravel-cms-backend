<?php $__env->startSection('content'); ?>

<section>
    <!--Banner-->
    <div class="w3-center w3-padding-24 page-banner">
        <h3>Manage Social Media</h3>
    </div>
    <!--Content-->
    <div class="w3-container w3-center w3-padding-32">
    <div class="w3-content w3-justify">
        <table class="w3-table w3-bordered w3-white">
            <tr>
                <th></th>
                <th>Name</th>
                <th>URL</th>
                <th>Type</th>
                <th>Created</th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
            <?php $__currentLoopData = $social_medias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social_media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php if($social_media->image): ?>
                            <img src="<?php echo e(asset('/storage/'.$social_media->image)); ?>" width="200">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($social_media->name); ?></td>
                    <td><a href="<?php echo e($social_media->url); ?>">Link</a></td>
                    <td><?php echo e($social_media->type); ?></td>
                    <td><?php echo e($social_media->created_at->format('M j, Y')); ?></td>
                    <td><a href="/console/social-media/image/<?php echo e($social_media->id); ?>" class="fake-button">Image</a></td>
                    <td><a href="/console/social-media/edit/<?php echo e($social_media->id); ?>" class="fake-button">Edit</a></td>
                    <td><a href="/console/social-media/delete/<?php echo e($social_media->id); ?>" class="fake-button">Delete</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div class="w3-center w3-padding-16">
            <a href="/console/social-media/add" class="w3-button button">New Social Media</a>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/LebronBrianSinza1/Desktop/Humber College/sem 2/HTTP-5212-RNA/PHP/assignments/Assignment 3/laravel-blade-cms/resources/views/social-media/list.blade.php ENDPATH**/ ?>