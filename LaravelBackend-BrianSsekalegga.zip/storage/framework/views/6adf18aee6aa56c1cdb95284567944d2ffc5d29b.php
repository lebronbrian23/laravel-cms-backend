<?php $__env->startSection('content'); ?>

<section>
    <!--Banner-->
    <div class="w3-center w3-padding-24 page-banner">
        <h3>Edit User</h3>
    </div>
    <!--Content-->
    <div class="w3-container w3-padding-32">
    <form method="post" action="/console/users/edit/<?php echo e($user->id); ?>" novalidate class="w3-margin-bottom">

        <?php echo csrf_field(); ?>

        <div class="w3-row-padding w3-margin-bottom">
            <div class="w3-col m4 w3-right-align">
            <label for="first">First Name:</label>
            </div><div class="w3-col m4">
            <input type="text" name="first" id="first" value="<?php echo e(old('first', $user->first)); ?>" required>
            
            <?php if($errors->first('first')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('first')); ?></span>
            <?php endif; ?>
        </div></div>

        <div class="w3-row-padding w3-margin-bottom">
            <div class="w3-col m4 w3-right-align">
            <label for="last">Last Name:</label>
            </div><div class="w3-col m4">
            <input type="text" name="last" id="last" value="<?php echo e(old('last', $user->last)); ?>" required>
            
            <?php if($errors->first('last')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('last')); ?></span>
            <?php endif; ?>
        </div></div>

        <div class="w3-row-padding w3-margin-bottom">
            <div class="w3-col m4 w3-right-align">
            <label for="email">Email:</label>
            </div><div class="w3-col m4">
            <input type="email" name="email" id="email" value="<?php echo e(old('email', $user->email)); ?>">

            <?php if($errors->first('email')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
        </div></div>

        <div class="w3-row-padding w3-margin-bottom">
            <div class="w3-col m4 w3-right-align">
            <label for="password">Password:</label>
            </div><div class="w3-col m4">
            <input type="password" name="password" id="password">

            <?php if($errors->first('password')): ?>
                <br>
                <span class="w3-text-red"><?php echo e($errors->first('password')); ?></span>
            <?php endif; ?>
        </div></div>

        <button type="submit" class="w3-button button">Edit User</button>

    </form>

    <a href="/console/users/list">Back to List</a>

</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/LebronBrianSinza1/Desktop/Humber College/sem 2/HTTP-5212-RNA/PHP/assignments/Assignment 3/laravel-blade-cms/resources/views/users/edit.blade.php ENDPATH**/ ?>