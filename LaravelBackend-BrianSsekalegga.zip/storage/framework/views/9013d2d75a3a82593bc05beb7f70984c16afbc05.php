<?php $__env->startSection('content'); ?>

<section>
    <!--Banner-->
    <div class="w3-center w3-padding-24 page-banner">
        <h3>Manage Content Blocks</h3>
    </div>
    <!--Content-->
    <div class="w3-container w3-center w3-padding-32">
        <div class="w3-content w3-justify">
        <table class="w3-table w3-bordered w3-white">
            <tr>
                <th></th>
                <th>Name</th>
                <th>Description</th>
                <th>Type</th>
                <th>Created</th>
                <th></th>
                <th></th>
                <th></th>
            </tr>
        <?php $__currentLoopData = $content_blocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $content_block): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if($content_block->image): ?>
                        <img src="<?php echo e(asset('/storage/'.$content_block->image)); ?>" width="200">
                    <?php endif; ?>
                </td>
                <td><?php echo e($content_block->name); ?></td>
                <td><?php echo e($content_block->description); ?></td>
                <td><?php echo e($content_block->type); ?></td>
                <td><?php echo e($content_block->created_at->format('M j, Y')); ?></td>
                <td><a href="/console/content-blocks/image/<?php echo e($content_block->id); ?>" class="fake-button">Image</a></td>
                <td><a href="/console/content-blocks/edit/<?php echo e($content_block->id); ?>" class="fake-button">Edit</a></td>
                <td><a href="/console/content-blocks/delete/<?php echo e($content_block->id); ?>" class="fake-button">Delete</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
        <div class="w3-center w3-padding-16">
            <a href="/console/content-blocks/add" class="w3-button button">New Content Block</a>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/LebronBrianSinza1/Desktop/Humber College/sem 2/HTTP-5212-RNA/PHP/assignments/Assignment 3/laravel-blade-cms/resources/views/content_blocks/list.blade.php ENDPATH**/ ?>