<?php $__env->startSection('content'); ?>

<section>
    <!--Banner-->
    <div class="w3-center w3-padding-24 page-banner">
        <h3>Manage Skills</h3>
    </div>
    <!--Content-->
    <div class="w3-container w3-center w3-padding-32">
    <div class="w3-content w3-justify">
      <table class="w3-table w3-bordered w3-white">
        <tr>
            <th></th>
            <th>Name</th>
            <th>Created</th>
            <th></th>
            <th></th>
            <th></th>
        </tr>
        <?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if($skill->image): ?>
                        <img src="<?php echo e(asset('/storage/'.$skill->image)); ?>" width="200">
                    <?php endif; ?>
                </td>
                <td><?php echo e($skill->name); ?></td>
                <td><?php echo e($skill->created_at->format('M j, Y')); ?></td>
                <td><a href="/console/skill/image/<?php echo e($skill->id); ?>" class="fake-button">Image</a></td>
                <td><a href="/console/skill/edit/<?php echo e($skill->id); ?>" class="fake-button">Edit</a></td>
                <td><a href="/console/skill/delete/<?php echo e($skill->id); ?>" class="fake-button">Delete</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
        <div class="w3-center w3-padding-16">
            <a href="/console/skill/add" class="w3-button button">New Skill</a>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.console', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/LebronBrianSinza1/Desktop/Humber College/sem 2/HTTP-5212-RNA/PHP/assignments/Assignment 3/laravel-blade-cms/resources/views/skill/list.blade.php ENDPATH**/ ?>